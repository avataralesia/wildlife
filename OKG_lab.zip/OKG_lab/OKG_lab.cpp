﻿//------------------------------------------------------
//	Файл:		BMPVIEW.CPP
//	Описание:	Демонстрирует работу с растрами
//------------------------------------------------------

#define STRICT
#define WIN32_LEAN_AND_MEAN 

#include <windows.h>
#include <windowsx.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "bmpview.h"

// Объекты контекста в памяти и шрифт
HDC	hMemDC; // Контекст устройства в памяти
HBITMAP hMemBitmap; // Битмап для хранения изображения
HFONT	hInfoFont; // Шрифт для отображения текста

// Два цвета для надписей
COLORREF crFontColor1; // Первый цвет текста
COLORREF crFontColor2; // Второй цвет текста

// Имя выводимого растра
const char* szFileName = "sample.bmp"; // Имя файла изображения

// Ширина и высота экрана
UINT	nScreenX; // Ширина экрана
UINT	nScreenY; // Высота экрана

// Реальные ширина и высота картинки
UINT	nBmpWidth; // Реальная ширина изображения
UINT	nBmpHeight; // Реальная высота изображения

// Ширина и высота картинки при выводе
UINT	nVBmpWidth; // Виртуальная ширина изображения
UINT	nVBmpHeight; // Виртуальная высота изображения

// Отступ сверху для надписи
UINT	nTopDown = 100; // Отступ сверху для текста

// Главная функция программы
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpszCmdLine, int nCmdShow)
{
	WNDCLASSEX wndClass; // Структура для описания класса окна
	HWND hWnd; // Дескриптор окна
	MSG msg; // Структура для обработки сообщений

	// Получаем размеры экрана
	nScreenX = GetSystemMetrics(SM_CXSCREEN);
	nScreenY = GetSystemMetrics(SM_CYSCREEN);

	// Регистрация оконного класса
	wndClass.cbSize = sizeof(wndClass);
	wndClass.style = CS_HREDRAW | CS_VREDRAW; // Перерисовка при изменении размеров
	wndClass.lpfnWndProc = WndProc; // Указатель на оконную процедуру
	wndClass.cbClsExtra = 0;
	wndClass.cbWndExtra = 0;
	wndClass.hInstance = hInst;
	wndClass.hIcon = LoadIcon(NULL, IDI_WINLOGO); // Иконка окна
	wndClass.hCursor = LoadCursor(NULL, IDC_ARROW); // Курсор
	wndClass.hbrBackground = GetStockBrush(BLACK_BRUSH); // Фон окна
	wndClass.lpszMenuName = NULL;
	wndClass.lpszClassName = szClassName; // Имя класса окна
	wndClass.hIconSm = LoadIcon(NULL, IDI_WINLOGO);

	RegisterClassEx(&wndClass);

	// Создание окна на основе зарегистрированного класса
	hWnd = CreateWindowEx(
		WS_EX_LEFT, // Дополнительный стиль окна
		szClassName, // Класс окна
		szAppName, // Заголовок окна
		WS_POPUP, // Стиль окна
		0, 0, // Координаты окна
		nScreenX, nScreenY, // Размеры окна
		NULL, // Родительское окно
		NULL, // Меню
		hInst, // Дескриптор экземпляра
		NULL); // Дополнительные данные

	ShowWindow(hWnd, nCmdShow); // Отображение окна
	UpdateWindow(hWnd); // Обновление окна

	// Главный цикл программы
	while (TRUE)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) // Проверка очереди сообщений
		{
			if (msg.message == WM_QUIT) // Если сообщение WM_QUIT, выходим из цикла
				break;

			TranslateMessage(&msg); // Трансляция сообщения
			DispatchMessage(&msg); // Передача сообщения оконной процедуре
		}
		else
			BMP_OnIdle(hWnd); // Выполнение фоновых задач
	}
	return (msg.wParam); // Возврат кода завершения
}

// Оконная процедура
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		HANDLE_MSG(hWnd, WM_CREATE, BMP_OnCreate); // Обработка создания окна
		HANDLE_MSG(hWnd, WM_DESTROY, BMP_OnDestroy); // Обработка уничтожения окна
		HANDLE_MSG(hWnd, WM_TIMER, BMP_OnTimer); // Обработка таймера
		HANDLE_MSG(hWnd, WM_KEYDOWN, BMP_OnKey); // Обработка нажатия клавиш
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam); // Обработка остальных сообщений
	}
}

// Обработчик создания окна
BOOL BMP_OnCreate(HWND hwnd, LPCREATESTRUCT lpCreateStruct)
{
	HDC hTempDC; // Временный контекст устройства

	// Получаем контекст рабочего стола
	hTempDC = GetDC(HWND_DESKTOP);

	// Создаём совместимый контекст в памяти и битмап
	hMemDC = CreateCompatibleDC(hTempDC);
	hMemBitmap = CreateCompatibleBitmap(hTempDC, nScreenX, nScreenY);

	// Заливаем контекст памяти черным цветом
	SelectBitmap(hMemDC, hMemBitmap);
	SelectBrush(hMemDC, GetStockBrush(BLACK_BRUSH));
	PatBlt(hMemDC, 0, 0, nScreenX, nScreenY, PATCOPY);

	wchar_t wFileName[MAX_PATH];
	// Конвертируем имя файла из многобайтового в широкий формат
	MultiByteToWideChar(CP_ACP, 0, szFileName, -1, wFileName, MAX_PATH);

	// Загружаем битмап в контекст памяти
	if (!LoadBMP(hMemDC, wFileName))
	{
		// Показываем сообщение об ошибке, если файл не найден
		MessageBox(hwnd, L"Не найден файл", L"Ошибка", MB_OK | MB_ICONSTOP);
		return (FALSE);
	}

	// Освобождаем временный контекст рабочего стола
	ReleaseDC(HWND_DESKTOP, hTempDC);

	// Создаём шрифт и переменные для цветов шрифта
	hInfoFont = CreateFont(22, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, VARIABLE_PITCH, L"Courier New");

	crFontColor1 = RGB(255, 0, 0); // Красный цвет
	crFontColor2 = RGB(0, 255, 0); // Зеленый цвет

	// Устанавливаем цвет текста для контекста памяти
	SetTextColor(hMemDC, crFontColor1);

	// Рисуем текст в контексте памяти
	ShowText();

	// Устанавливаем таймер для периодических обновлений
	if (!SetTimer(hwnd, TIMER_ID, TIMER_RATE, NULL))
		return (FALSE);
	return (TRUE);
}

// Обработчик уничтожения окна
void BMP_OnDestroy(HWND hwnd)
{
	// Освобождаем ресурсы
	KillTimer(hwnd, TIMER_ID); // Останавливаем таймер
	DeleteDC(hMemDC); // Удаляем контекст памяти
	DeleteBitmap(hMemBitmap); // Удаляем битмап
	DeleteFont(hInfoFont); // Удаляем шрифт
	PostQuitMessage(0); // Завершаем приложение
}

// Обработчик таймера
void BMP_OnTimer(HWND hwnd, UINT id)
{
	// Обновляем текст в контексте памяти
	ShowText();
}

// Обработчик фоновых задач
void BMP_OnIdle(HWND hwnd)
{
	HDC hWindowDC; // Контекст окна
	// Получаем контекст окна и копируем в него содержимое контекста памяти
	hWindowDC = GetDC(hwnd);
	BitBlt(hWindowDC, 0, 0, nScreenX, nScreenY, hMemDC, 0, 0, SRCCOPY);
	ReleaseDC(hwnd, hWindowDC); // Освобождаем контекст окна
}

// Обработчик нажатия клавиш
void BMP_OnKey(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags)
{
	// Если нажата клавиша пробела, закрываем приложение
	if (vk == VK_SPACE)
		DestroyWindow(hwnd);
}


//-------------------------------------------------------------------

/* Копирует содержимое файла BMP в контекст устройства */

BOOL LoadBMP(HDC hdc, LPCWSTR szFileName)
{
	BYTE* pBmp;
	DWORD dwBmpSize;
	DWORD dwFileLength;
	DWORD dwBytesRead;

	BITMAPFILEHEADER BmpHeader;
	BITMAPINFO* pBmpInfo;
	BYTE* pPixels;


	//Пытаемся открыть файл
	HANDLE hFile = CreateFile(szFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);

	if (hFile == INVALID_HANDLE_VALUE)
		return (FALSE);

	//Определяем размер данных, которые необходимо загрузить
	dwFileLength = GetFileSize(hFile, NULL);
	dwBmpSize = dwFileLength - sizeof(BITMAPFILEHEADER);

	//Выделяем память и считываем данные
	pBmp = (BYTE*)malloc(dwBmpSize);
	ReadFile(hFile, &BmpHeader, sizeof(BmpHeader), &dwBytesRead, NULL);
	ReadFile(hFile, (LPVOID)pBmp, dwBmpSize, &dwBytesRead, NULL);
	CloseHandle(hFile);

	//Инициализируем указатели на информацию о картинке
	//и на графические данные
	pBmpInfo = (BITMAPINFO*)pBmp;
	pPixels = pBmp + BmpHeader.bfOffBits - sizeof(BITMAPFILEHEADER);

	//Получаем ширину и высоту картинки
	nBmpHeight = pBmpInfo->bmiHeader.biHeight;
	nBmpWidth = pBmpInfo->bmiHeader.biWidth;

	//Вычистляем ширину и высоту картинки для вывода на экран
	nVBmpHeight = nScreenY - nTopDown * 2;
	nVBmpWidth = (UINT)((double)nBmpWidth * (double)nVBmpHeight / (double)nBmpHeight);
	if (nVBmpWidth > nScreenX)
		nVBmpWidth = nScreenX;


	//Устанавливаем режим масштабирования
	SetStretchBltMode(hdc, HALFTONE);

	//Копируем картинку в контекст памяти
	StretchDIBits(hdc, (nScreenX - nVBmpWidth) / 2, nTopDown, nVBmpWidth, nVBmpHeight, 0, 0, nBmpWidth, nBmpHeight, pPixels, pBmpInfo, 0, SRCCOPY);

	//Освобождаем память
	free(pBmp);
	return (TRUE);
}

/* Меняет текущий цвет шрифта и выводит текст в контекст памяти */
void ShowText()
{
	HFONT hOldFont; // Хранит старый шрифт для восстановления
	RECT rTextRect; // Прямоугольник для размещения текста
	wchar_t szInfoText[256]; // Буфер для информационного текста

	// Определяем текущий цвет шрифта и меняем его
	if (GetTextColor(hMemDC) == crFontColor1)
		SetTextColor(hMemDC, crFontColor2); // Меняем на второй цвет
	else
		SetTextColor(hMemDC, crFontColor1); // Меняем на первый цвет

	// Настраиваем режим фона для текста
	SetBkMode(hMemDC, TRANSPARENT); // Устанавливаем прозрачный фон
	hOldFont = SelectFont(hMemDC, hInfoFont); // Выбираем новый шрифт

	// Устанавливаем прямоугольник для вывода текста
	SetRect(&rTextRect, 0, 0, nScreenX, nTopDown);

	// Конвертируем имя файла из многобайтового в широкий формат
	wchar_t wFileName[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, szFileName, -1, wFileName, MAX_PATH);

	// Выводим имя файла в контексте памяти
	DrawText(hMemDC, wFileName, strlen(szFileName), &rTextRect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

	// Формируем информационный текст с размерами
	wsprintf(szInfoText, L"Tihonenko Ilya, Astashonok Dmitry, Lisovsky Nikolay, Zemlyanushina Maria 481573\nReal width-%d, Real height-%d\n Virtual width-%d, Virtual height-%d", nBmpWidth, nBmpHeight, nVBmpWidth, nVBmpHeight);

	// Устанавливаем прямоугольник для вывода информационного текста
	SetRect(&rTextRect, 0, nScreenY - nTopDown, nScreenX, nScreenY);

	// Выводим информационный текст в контексте памяти
	DrawText(hMemDC, szInfoText, wcslen(szInfoText), &rTextRect, DT_CENTER);

	// Восстанавливаем старый шрифт
	SelectFont(hMemDC, hOldFont);
}
